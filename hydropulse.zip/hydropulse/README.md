# HydroPulse — Project Structure

Water-tracking app prototype for the University of Santo Tomas campus.

## Directory Layout

```
hydropulse/
├── index.html          ← Entry point; loads all CSS & JS
├── css/
│   ├── base.css        ← Global reset, layout, shared components
│   │                     (phone shell, topbar, card, tabs, badges, toast, building dropdowns, log items)
│   ├── dashboard.css   ← Home / Pulse screen styles
│   ├── log.css         ← Log screen + inline calendar dropdown styles
│   ├── map.css         ← Map screen + fountain popup styles
│   ├── rewards.css     ← Rewards / Perks screen styles + level themes
│   ├── scan.css        ← Scan & feedback screen styles
│   └── calendar.css    ← Standalone calendar screen styles
├── js/
│   ├── state.js        ← Global state, levels, nav, badges, toast, building dropdowns
│   ├── calendar.js     ← calData + standalone calendar screen logic
│   ├── dashboard.js    ← Home ring, slider/input sync, manual intake
│   ├── log.js          ← Log screen calendar dropdown logic
│   ├── map.js          ← Fountain popup + floor list logic
│   ├── rewards.js      ← Rewards data, redeem logic, level progression UI
│   └── scan.js         ← QR scan simulation + feedback/submit flow
└── screens/
    ├── home.html       ← Dashboard screen HTML partial
    ├── log.html        ← Log screen HTML partial
    ├── map.html        ← Map screen HTML partial
    ├── rewards.html    ← Rewards screen HTML partial
    ├── calendar.html   ← Calendar screen HTML partial
    └── scan.html       ← Scan screen HTML partial
```

## Script Load Order

`state.js` must load first — it defines the global state and shared utility
functions (`goTo`, `showToast`, `toggleBldg`, `getLevel`, etc.) that every
other module depends on. `calendar.js` comes second because it defines
`calData`, which `log.js` reads.

```
state.js → calendar.js → dashboard.js → log.js → map.js → rewards.js → scan.js
```

## Using the Screens in index.html

Because this is a vanilla HTML prototype (no bundler), the screen partials in
`screens/` are the authoritative source for each view's markup. Paste their
contents into the marked sections inside `index.html`, or adopt a build tool:

- **Vite / Parcel** — use `vite-plugin-html` or similar to inline partials
- **React / Vue** — convert each screen into a component
- **Express / PHP** — use server-side includes

## Potential Next Steps

- [ ] Move inline styles from HTML partials into the relevant CSS files
- [ ] Replace `var` with `const`/`let` and arrow functions
- [ ] Extract `calData` to `data/hydration.json` and `MONTHLY_REWARDS` to `data/rewards.json`
- [ ] Add a `localStorage` persistence layer in `state.js`
- [ ] Set up a bundler (Vite recommended) to eliminate the manual screen-paste step
