// ===== REWARDS / PERKS SCREEN =====

// Monthly featured rewards (one per month, cycles)
var MONTHLY_REWARDS = [
  { icon: '🥤', title: 'HydroPulse Tumbler',       tag: 'EXCLUSIVE', sub: '32oz insulated stainless tumbler',     desc: 'Double-wall · leak-proof · HydroPulse logo',   pts: '🏆 1,500 pts · Tidal Wave only',   cost: 1500, minLevel: 3 },
  { icon: '👕', title: 'UST HydroPulse Shirt',      tag: 'LIMITED',   sub: 'Eco-friendly cotton campus tee',        desc: 'Sizes S–XL · UST blue colorway',               pts: '⚡ 800 pts · Current level+',       cost: 800,  minLevel: 2 },
  { icon: '🎒', title: 'HydroPulse Bag',            tag: 'NEW',       sub: 'Recycled-material campus backpack',     desc: 'Waterproof · laptop sleeve · HydroPulse patch', pts: '💧 1,200 pts · Ripple level+',      cost: 1200, minLevel: 1 },
  { icon: '☕', title: "Tiger's Den Gift Card",      tag: 'PARTNER',   sub: '₱200 voucher at Tiger\'s Den café',    desc: 'Valid for 30 days after redemption',            pts: '🌊 600 pts · Droplet level',        cost: 600,  minLevel: 0 },
  { icon: '🎧', title: 'Wireless Earbuds',           tag: 'RARE',      sub: 'Campus store branded earbuds',          desc: '12hr battery · USB-C charging',                pts: '🏆 2,000 pts · Tidal Wave only',   cost: 2000, minLevel: 3 },
  { icon: '📓', title: 'HydroPulse Notebook Set',   tag: 'MONTHLY',   sub: 'Eco journal + sticker pack bundle',     desc: 'A5 size · 120 pages · recycled paper',         pts: '💧 300 pts · All levels',           cost: 300,  minLevel: 0 },
  { icon: '🧴', title: 'UST Merch Bundle',           tag: 'BUNDLE',    sub: 'Tumbler + shirt combo set',             desc: 'Exclusive pairing · limited stock',             pts: '🏆 1,800 pts · Current+',           cost: 1800, minLevel: 2 },
  { icon: '🌱', title: 'Plant a Tree on Campus',     tag: 'ECO',       sub: 'UST plants a tree in your name',        desc: 'Certificate emailed to you',                   pts: '⚡ 500 pts · All levels',            cost: 500,  minLevel: 0 },
  { icon: '🎟️', title: 'UST Event VIP Pass',        tag: 'EVENT',     sub: 'Priority access to next campus event',  desc: '1 event · non-transferable',                   pts: '🌊 700 pts · Ripple+',              cost: 700,  minLevel: 1 },
  { icon: '🪄', title: 'Custom HydroPulse Sticker Pack', tag: 'FUN',  sub: '10-sticker exclusive set',              desc: 'Waterproof · limited design',                  pts: '💧 150 pts · All levels',           cost: 150,  minLevel: 0 },
  { icon: '🏅', title: 'Gold Pulse Badge (Physical)', tag: 'PRESTIGE', sub: 'Engraved HydroPulse collector badge',  desc: 'Limited edition · numbered',                   pts: '🏆 2,500 pts · Tidal Wave',        cost: 2500, minLevel: 3 },
  { icon: '🧊', title: 'Insulated Water Bottle',    tag: 'CLASSIC',   sub: 'HydroPulse branded 24oz bottle',        desc: 'BPA-free · keeps cold 24hr',                   pts: '💧 400 pts · All levels',           cost: 400,  minLevel: 0 },
];

function initFeaturedReward() {
  var now = new Date();
  var reward = MONTHLY_REWARDS[now.getMonth() % MONTHLY_REWARDS.length];
  var daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  var daysLeft = daysInMonth - now.getDate();

  document.getElementById('featured-icon').textContent = reward.icon;
  document.getElementById('featured-title').innerHTML = reward.title + ' <span class="tumbler-tag">' + reward.tag + '</span>';
  document.getElementById('featured-sub').textContent = reward.sub;
  document.getElementById('featured-desc').textContent = reward.desc;
  document.getElementById('featured-pts').textContent = reward.pts;
  document.getElementById('countdown-bar').style.width = (daysLeft / daysInMonth * 100) + '%';
  window._featuredReward = reward;
  updateFeaturedBtn();

  function tickCountdown() {
    var n = new Date();
    var endOfMonth = new Date(n.getFullYear(), n.getMonth() + 1, 0, 23, 59, 59);
    var diff = Math.max(0, Math.floor((endOfMonth - n) / 1000));
    var h = Math.floor(diff / 3600);
    var m = Math.floor((diff % 3600) / 60);
    var s = diff % 60;
    var pad = function (v) { return (v < 10 ? '0' : '') + v; };
    var el = document.getElementById('countdown-clock');
    if (el) el.textContent = pad(h) + ':' + pad(m) + ':' + pad(s);
    var dLeft = new Date(n.getFullYear(), n.getMonth() + 1, 0).getDate() - n.getDate();
    var bar = document.getElementById('countdown-bar');
    if (bar) bar.style.width = Math.max(0, (dLeft / new Date(n.getFullYear(), n.getMonth() + 1, 0).getDate()) * 100) + '%';
  }
  tickCountdown();
  setInterval(tickCountdown, 1000);
}

function updateFeaturedBtn() {
  var reward = window._featuredReward;
  if (!reward) return;
  var btn = document.getElementById('tumbler-btn');
  var lvlIdx = getLevel(points);
  if (btn.hasAttribute('data-redeemed')) { btn.textContent = 'Claimed!'; btn.disabled = true; return; }
  if (lvlIdx >= reward.minLevel && points >= reward.cost) { btn.disabled = false; btn.textContent = 'Claim'; }
  else { btn.disabled = true; btn.textContent = 'Locked'; }
}

function redeemFeatured() {
  var reward = window._featuredReward;
  if (!reward || points < reward.cost) return;
  points -= reward.cost;
  document.getElementById('points-val').textContent = points;
  document.getElementById('pts-display').textContent = points + ' Pulse Points';
  var btn = document.getElementById('tumbler-btn');
  btn.disabled = true; btn.textContent = 'Claimed!'; btn.setAttribute('data-redeemed', '1');
  showToast(reward.icon, reward.title + ' claimed!', 'Check your UST email for details.');
  setTimeout(updateRewards, 500);
}

function redeem(btn, cost, name, icon) {
  if (points < cost) {
    showToast('⚠️', 'Not enough points', 'Need ' + (cost - points) + ' more Pulse Points');
    return;
  }
  points -= cost;
  btn.disabled = true; btn.textContent = 'Redeemed!'; btn.setAttribute('data-redeemed', '1');
  document.getElementById('points-val').textContent = points;
  document.getElementById('pts-display').textContent = points + ' Pulse Points';
  showToast(icon || '🎉', name + ' redeemed!', 'Check your UST email for your voucher.');
  setTimeout(function () { updateRewards(); }, 500);
}

function updateRewards() {
  updateAllBadges();
  var idx = getLevel(points);
  var lvl = LEVELS[idx];
  var card = document.getElementById('level-card');
  ['lvl-droplet', 'lvl-ripple', 'lvl-current', 'lvl-tidal'].forEach(function (c) { card.classList.remove(c); });
  card.classList.add(lvl.theme);
  document.getElementById('level-name').textContent = lvl.name;
  document.getElementById('pts-display').textContent = points + ' Pulse Points';
  document.getElementById('level-bonus').textContent = lvl.bonus;

  var fill = document.getElementById('level-bar');
  ['bar-droplet', 'bar-ripple', 'bar-current', 'bar-tidal'].forEach(function (c) { fill.classList.remove(c); });
  fill.classList.add(lvl.bar);
  var range = idx < LEVELS.length - 1 ? LEVELS[idx].max - LEVELS[idx].min + 1 : 1000;
  fill.style.width = Math.min((points - lvl.min) / range * 100, 100) + '%';
  document.getElementById('level-next').textContent =
    idx < LEVELS.length - 1 ? (LEVELS[idx].max + 1 - points) + ' pts to ' + LEVELS[idx + 1].name : 'Max level — Tidal Wave! 🏆';

  // Unlock gated rewards
  var uniRow = document.getElementById('unibelt-row');
  var uniBtn = document.getElementById('btn-unibelt');
  if (idx >= 1) { uniRow.style.opacity = '1'; if (!uniBtn.hasAttribute('data-redeemed')) { uniBtn.disabled = false; uniBtn.textContent = 'Redeem'; } }
  var tBtn = document.getElementById('tumbler-btn');
  if (idx >= 3 && points >= 1500) { if (!tBtn.hasAttribute('data-redeemed')) { tBtn.disabled = false; tBtn.textContent = 'Claim'; } }
  else { if (!tBtn.hasAttribute('data-redeemed')) { tBtn.disabled = true; tBtn.textContent = 'Locked'; } }
  updateFeaturedBtn();

  // Level progression ladder highlight
  var levelKeys   = ['droplet', 'ripple', 'current', 'tidal'];
  var levelBgs    = ['linear-gradient(135deg,#1E375F,#34A1D8)', 'linear-gradient(135deg,#003a52,#00bcd4)', 'linear-gradient(135deg,#1a3a1a,#4CAF50)', 'linear-gradient(135deg,#3d1a00,#ff6f00)'];
  var levelBorders = ['#34A1D8', '#00bcd4', '#4CAF50', '#ff6f00'];
  levelKeys.forEach(function (key, i) {
    var badge    = document.getElementById('badge-' + key);
    var cardEl   = document.getElementById('card-' + key);
    var curBadge = document.getElementById('cur-badge-' + key);
    if (i < idx) {
      if (badge)    { badge.style.background = levelBgs[i]; badge.style.opacity = '0.55'; badge.style.border = 'none'; badge.style.boxShadow = 'none'; }
      if (cardEl)   { cardEl.style.opacity = '0.5'; cardEl.style.background = '#F5F7FA'; cardEl.style.border = '1.5px solid #E0E7EF'; }
      if (curBadge) curBadge.style.display = 'none';
    } else if (i === idx) {
      if (badge)    { badge.style.background = levelBgs[i]; badge.style.opacity = '1'; badge.style.border = '2px solid ' + levelBorders[i]; badge.style.boxShadow = '0 2px 10px rgba(0,0,0,0.25)'; }
      if (cardEl)   { cardEl.style.opacity = '1'; cardEl.style.background = '#fff'; cardEl.style.border = '2px solid ' + levelBorders[i]; }
      if (curBadge) curBadge.style.display = 'inline-block';
    } else {
      if (badge)    { badge.style.background = '#ccc'; badge.style.opacity = '0.35'; badge.style.border = 'none'; badge.style.boxShadow = 'none'; }
      if (cardEl)   { cardEl.style.opacity = '0.35'; cardEl.style.background = '#F5F7FA'; cardEl.style.border = '1.5px solid #E0E7EF'; }
      if (curBadge) curBadge.style.display = 'none';
    }
  });
}

// Level progression dropdown
var levelProgOpen = false;
function toggleLevelProg() {
  levelProgOpen = !levelProgOpen;
  document.getElementById('level-prog-body').style.display = levelProgOpen ? 'block' : 'none';
  document.getElementById('level-prog-arrow').style.transform = levelProgOpen ? 'rotate(180deg)' : '';
}
