// ===== SCAN / FEEDBACK SCREEN =====

function simulateScan() {
  document.getElementById('scan-view').style.display = 'none';
  document.getElementById('feedback-view').style.display = 'block';
}

function submitFeedback() {
  var scanMl = 500;
  var earned = calcFountainPoints(scanMl);
  points  += earned;
  intake  += scanMl;
  bottles = Math.floor(intake / 500);

  document.getElementById('points-val').textContent = points;
  document.getElementById('pts-display').textContent = points + ' Pulse Points';
  document.getElementById('feedback-pts-msg').textContent = '+' + earned + ' Pulse Points added · Roque Ruaño (Floor 1)';
  document.getElementById('feedback-success').style.display = 'block';
  document.getElementById('submit-btn').style.display = 'none';

  // Add entry to Roque Ruaño dropdown in log
  var now = new Date();
  var t = now.getHours() + ':' + (now.getMinutes() < 10 ? '0' : '') + now.getMinutes();
  var item = document.createElement('div');
  item.className = 'refill-item';
  item.innerHTML =
    '<div class="ri-icon fountain"><svg width="14" height="14" viewBox="0 0 14 14" fill="none">' +
    '<path d="M7 1C7 1 3 5.5 3 8.5a4 4 0 008 0C11 5.5 7 1 7 1z" fill="#34A1D8"/></svg></div>' +
    '<div><div class="ri-loc">Floor 1 – Scanned at ' + t + '</div>' +
    '<div class="ri-detail">Filter 92% · ' + t + '</div>' +
    '<span class="ri-badge fountain-badge">🚰 Fountain · +' + earned + ' pts</span></div>' +
    '<div class="ri-vol">' + scanMl + ' mL</div>';
  document.getElementById('bldg-entries-roque').insertBefore(item, document.getElementById('bldg-entries-roque').firstChild);

  // Auto-return to home after showing success
  setTimeout(function () {
    goTo('home');
    document.getElementById('scan-view').style.display = 'block';
    document.getElementById('feedback-view').style.display = 'none';
    document.getElementById('feedback-success').style.display = 'none';
    document.getElementById('submit-btn').style.display = 'block';
  }, 2200);
}
