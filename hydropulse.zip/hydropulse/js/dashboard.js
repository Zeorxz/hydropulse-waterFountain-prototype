// ===== HOME / DASHBOARD =====

function updateRing() {
  var pct = Math.min(intake / goal, 1);
  document.getElementById('ring-progress').style.strokeDashoffset = 377 - (377 * pct);
  document.getElementById('ring-pct').textContent = Math.round(pct * 100) + '%';
  document.getElementById('ring-amt').textContent = (intake / 1000).toFixed(1) + ' / ' + (goal / 1000).toFixed(1) + ' L';
  document.getElementById('ring-status').textContent =
    pct < 0.3 ? 'Drink more!' :
    pct < 0.6 ? 'Keep it up!' :
    pct < 0.9 ? 'Almost there!' : 'Goal reached! 🎉';
  document.getElementById('bottles-val').textContent = bottles;
  document.getElementById('points-val').textContent = points;
  updateAllBadges();
}

// ===== SLIDER + NUMBER INPUT SYNC =====
var slider = document.getElementById('intake-slider');
var numInput = document.getElementById('intake-input');

slider.addEventListener('input', function () {
  var v = parseInt(this.value) || 100;
  numInput.value = v;
});

numInput.addEventListener('input', function () {
  this.value = this.value.replace(/[^0-9]/g, '');
  var v = parseInt(this.value) || 0;
  if (v > 0 && v <= 750) slider.value = v;
});

// Manual intake — NO points earned
function addIntake() {
  var raw = parseInt(numInput.value) || parseInt(slider.value) || 0;
  var ml = Math.max(1, Math.min(raw, 9999));
  if (!ml || isNaN(ml)) return;

  intake += ml;
  manualTotalMl += ml;
  bottles = Math.floor(intake / 500);
  updateRing();

  var now = new Date();
  var t = now.getHours() + ':' + (now.getMinutes() < 10 ? '0' : '') + now.getMinutes();

  var item = document.createElement('div');
  item.className = 'refill-item';
  item.innerHTML =
    '<div class="ri-icon manual"><svg width="14" height="14" viewBox="0 0 14 14" fill="none">' +
    '<path d="M7 1C7 1 3 5.5 3 8.5a4 4 0 008 0C11 5.5 7 1 7 1z" fill="#3B7DD8"/></svg></div>' +
    '<div><div class="ri-loc">Manual Entry</div><div class="ri-detail">Logged at ' + t + '</div>' +
    '<span class="ri-badge manual-badge">✏️ Manual · No pts</span></div>' +
    '<div class="ri-vol" style="color:#3B7DD8;">' + ml + ' mL</div>';

  var placeholder = document.getElementById('manual-entries-list').querySelector('div[style]');
  if (placeholder) placeholder.remove();
  document.getElementById('manual-entries-list').insertBefore(
    item, document.getElementById('manual-entries-list').firstChild
  );
  document.getElementById('manual-total-label').textContent = manualTotalMl + ' mL';
}
