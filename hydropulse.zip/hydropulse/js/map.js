// ===== MAP SCREEN =====

function showFloorPopup(name, status, cold, filter, temp, x, y, floors) {
  var p = document.getElementById('fountain-popup');
  document.getElementById('fp-name').textContent = name;
  document.getElementById('fp-status').textContent = status;
  document.getElementById('fp-temp').textContent = temp;
  document.getElementById('fp-filter').textContent = filter;
  document.getElementById('fp-cold').textContent = cold;

  var floorsList = document.getElementById('fp-floors-list');
  var floorsWrap = document.getElementById('fp-floors-wrap');

  if (floors && floors.length > 0) {
    floorsWrap.style.display = 'block';
    floorsList.innerHTML = '';
    floors.forEach(function (f, i) {
      var row = document.createElement('div');
      row.style.cssText =
        'display:flex;justify-content:space-between;align-items:center;font-size:10px;padding:3px 0;border-bottom:' +
        (i < floors.length - 1 ? '0.5px solid rgba(255,255,255,0.1)' : 'none');
      var parts = f.split('—');
      var isFirst = (i === 0);
      row.innerHTML =
        '<span style="color:' + (isFirst ? '#fff' : 'rgba(255,255,255,0.6)') + ';">' + (parts[0] || f) + '</span>' +
        (parts[1] ? '<span style="color:#34A1D8;font-weight:500;">' + parts[1].trim() + '</span>' : '') +
        (isFirst ? '<span style="font-size:8px;background:rgba(52,161,216,0.25);color:#34A1D8;border-radius:3px;padding:1px 4px;margin-left:4px;">Last visit</span>' : '');
      floorsList.appendChild(row);
    });
  } else {
    floorsWrap.style.display = 'none';
  }

  p.style.display = 'block';

  // Smart positioning — prefer below-right, flip if overflow
  var popupH = p.offsetHeight || 200;
  var mapH = 260, mapW = 304;
  var popupW = p.offsetWidth || 165;
  var leftPos = x + 12;
  var topPos  = y + 12;
  if (leftPos + popupW > mapW - 4) leftPos = x - popupW - 6;
  if (topPos + popupH > mapH - 4) topPos = y - popupH - 6;
  if (leftPos < 4) leftPos = 4;
  if (topPos < 4)  topPos = 4;
  p.style.left = leftPos + 'px';
  p.style.top  = topPos + 'px';
}

// Alias for markers without floor data
function showPopup(name, status, cold, filter, temp, x, y) {
  showFloorPopup(name, status, cold, filter, temp, x, y, []);
}

function closePopup() {
  document.getElementById('fountain-popup').style.display = 'none';
}
