// ===== STANDALONE CALENDAR SCREEN =====

// Historical hydration data (keyed by day-of-month)
var calData = {
   1: { ml: 2600, refills: 5, pts: 26, goalMet: true  },
   2: { ml: 1800, refills: 3, pts: 15, goalMet: false },
   3: { ml: 2500, refills: 5, pts: 25, goalMet: true  },
   4: { ml: 2100, refills: 4, pts: 18, goalMet: false },
   5: { ml: 2700, refills: 5, pts: 27, goalMet: true  },
   6: { ml: 0,    refills: 0, pts: 0,  goalMet: false },
   7: { ml: 3000, refills: 6, pts: 30, goalMet: true  },
   8: { ml: 2500, refills: 5, pts: 25, goalMet: true  },
   9: { ml: 1500, refills: 3, pts: 12, goalMet: false },
  10: { ml: 2800, refills: 5, pts: 28, goalMet: true  },
  11: { ml: 2600, refills: 5, pts: 26, goalMet: true  },
  12: { ml: 900,  refills: 2, pts: 8,  goalMet: false },
  13: { ml: 2500, refills: 5, pts: 25, goalMet: true  },
  14: { ml: 2200, refills: 4, pts: 20, goalMet: false },
  15: { ml: 3100, refills: 6, pts: 31, goalMet: true  },
  16: { ml: 2700, refills: 5, pts: 27, goalMet: true  },
  17: { ml: 1100, refills: 2, pts: 9,  goalMet: false },
  18: { ml: 2500, refills: 5, pts: 25, goalMet: true  },
  19: { ml: 2500, refills: 5, pts: 25, goalMet: true  },
  20: { ml: 2000, refills: 4, pts: 18, goalMet: false },
  21: { ml: 2900, refills: 5, pts: 29, goalMet: true  },
  22: { ml: 1200, refills: 3, pts: 13, goalMet: false },
};

var calViewYear, calViewMonth;
(function () {
  var d = new Date();
  calViewYear  = d.getFullYear();
  calViewMonth = d.getMonth();
})();

function changeMonth(dir) {
  calViewMonth += dir;
  if (calViewMonth > 11) { calViewMonth = 0; calViewYear++; }
  if (calViewMonth < 0)  { calViewMonth = 11; calViewYear--; }
  renderCalendar();
}

function renderCalendar() {
  var now = new Date();
  var mNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  document.getElementById('cal-month-label').textContent = mNames[calViewMonth] + ' ' + calViewYear;

  var grid = document.getElementById('cal-grid');
  grid.innerHTML = '';

  ['Su','Mo','Tu','We','Th','Fr','Sa'].forEach(function (d) {
    var h = document.createElement('div');
    h.className = 'cal-day-name';
    h.textContent = d;
    grid.appendChild(h);
  });

  var firstDay = new Date(calViewYear, calViewMonth, 1).getDay();
  var dim = new Date(calViewYear, calViewMonth + 1, 0).getDate();

  for (var e = 0; e < firstDay; e++) {
    var em = document.createElement('div');
    em.className = 'cal-day empty-slot';
    grid.appendChild(em);
  }

  for (var d = 1; d <= dim; d++) {
    var cell = document.createElement('div');
    cell.className = 'cal-day';
    var isToday = (d === now.getDate() && calViewMonth === now.getMonth() && calViewYear === now.getFullYear());
    var data = calData[d];
    if (isToday) cell.classList.add('today');
    if (data && data.ml > 0) {
      cell.classList.add('has-data');
      cell.classList.add(data.goalMet ? 'goal-met' : 'partial');
    }
    cell.textContent = d;
    (function (day, dat, isTd) {
      cell.onclick = function () { showCalDay(day, dat, isTd); };
    })(d, data, isToday);
    grid.appendChild(cell);
  }

  document.getElementById('cal-day-detail').style.display = 'none';
}

function showCalDay(day, data, isToday) {
  var mNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  document.getElementById('cal-day-detail').style.display = 'block';
  document.getElementById('cal-det-date').textContent = mNames[calViewMonth] + ' ' + day + (isToday ? ' (Today)' : '');

  if (!data || data.ml === 0) {
    document.getElementById('cal-det-intake').textContent = 'No data';
    document.getElementById('cal-det-refills').textContent = '—';
    document.getElementById('cal-det-pts').textContent = '—';
    document.getElementById('cal-det-goal').textContent = '—';
    return;
  }

  if (isToday) {
    document.getElementById('cal-det-intake').textContent = (intake / 1000).toFixed(1) + ' L';
    document.getElementById('cal-det-refills').textContent = '3 scans today';
    document.getElementById('cal-det-pts').textContent = points + ' pts total';
    document.getElementById('cal-det-goal').textContent = intake >= goal ? '✅ Goal met' : '⏳ In progress';
  } else {
    document.getElementById('cal-det-intake').textContent = (data.ml / 1000).toFixed(1) + ' L';
    document.getElementById('cal-det-refills').textContent = data.refills + ' fountain scan' + (data.refills !== 1 ? 's' : '');
    document.getElementById('cal-det-pts').textContent = '+' + data.pts + ' pts';
    document.getElementById('cal-det-goal').textContent = data.goalMet ? '✅ Goal met' : '⚠️ Below goal';
  }
}
