// ===== GLOBAL STATE =====
var intake = 1200, goal = 2500, points = 340, bottles = 126;
var manualTotalMl = 0;

// ===== LEVEL DEFINITIONS =====
var LEVELS = [
  { name: '💧 Droplet',    min: 0,    max: 499,      pts: 5, bonus: 'Base rate: 5 pts / 500mL', theme: 'lvl-droplet', bar: 'bar-droplet' },
  { name: '🌊 Ripple',     min: 500,  max: 999,      pts: 6, bonus: '+1 bonus: 6 pts / 500mL',  theme: 'lvl-ripple',  bar: 'bar-ripple'  },
  { name: '🌀 Current',    min: 1000, max: 1999,     pts: 7, bonus: '+2 bonus: 7 pts / 500mL',  theme: 'lvl-current', bar: 'bar-current' },
  { name: '🌊 Tidal Wave', min: 2000, max: Infinity, pts: 8, bonus: '+3 bonus: 8 pts / 500mL',  theme: 'lvl-tidal',   bar: 'bar-tidal'   }
];

function getLevel(p) {
  for (var i = 0; i < LEVELS.length; i++) {
    if (p >= LEVELS[i].min && p <= LEVELS[i].max) return i;
  }
  return LEVELS.length - 1;
}

function calcFountainPoints(ml) {
  return Math.round((ml / 500) * LEVELS[getLevel(points)].pts);
}

// ===== NAVIGATION =====
function goTo(s) {
  document.querySelectorAll('.screen').forEach(function (el) { el.classList.remove('active'); });
  document.getElementById('s-' + s).classList.add('active');
  if (s === 'home')     updateRing();
  if (s === 'rewards')  updateRewards();
  if (s === 'calendar') renderCalendar();
  if (s === 'log')      renderLogCalendar();
}

// ===== BADGES & POINTS BAR =====
function updateAllBadges() {
  var idx = getLevel(points), num = idx + 1;
  var cls = ['', 'lv2', 'lv3', 'lv4'];
  ['home', 'log', 'map', 'rewards'].forEach(function (id) {
    var b = document.getElementById(id + '-badge');
    if (!b) return;
    b.className = 'level-badge' + (cls[idx] ? ' ' + cls[idx] : '');
    if (id === 'rewards') b.style.cursor = 'default';
    document.getElementById(id + '-badge-num').textContent = num;
  });
  var bar = document.getElementById('home-pts-bar');
  if (bar) {
    var lvl = LEVELS[idx];
    var rMax = idx < LEVELS.length - 1 ? LEVELS[idx].max : lvl.min + 999;
    var pct = Math.min((points - lvl.min) / (rMax - lvl.min + 1) * 100, 100);
    bar.style.width = pct + '%';
    bar.style.background = ['#F5BA42', '#00e5ff', '#69f0ae', '#ffab40'][idx];
    document.getElementById('home-pts-cur').textContent = points + ' pts';
    document.getElementById('home-pts-next').textContent = idx < LEVELS.length - 1 ? (LEVELS[idx].max + 1) + ' pts' : 'MAX';
  }
}

// ===== FLOATING TOAST =====
var toastTimer = null;
function showToast(icon, title, sub) {
  var t = document.getElementById('toast-popup');
  document.getElementById('toast-icon').textContent = icon;
  document.getElementById('toast-title').textContent = title;
  document.getElementById('toast-sub').textContent = sub;
  t.className = 'toast-popup show';
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(function () {
    t.className = 'toast-popup hide';
    setTimeout(function () { t.className = 'toast-popup'; }, 350);
  }, 3200);
}

// ===== BUILDING DROPDOWNS =====
function toggleBldg(id) {
  var entries = document.getElementById('bldg-entries-' + id);
  var arrow = document.getElementById('bldg-arrow-' + id);
  var isOpen = entries.classList.contains('open');
  entries.classList.toggle('open', !isOpen);
  arrow.classList.toggle('open', !isOpen);
}
