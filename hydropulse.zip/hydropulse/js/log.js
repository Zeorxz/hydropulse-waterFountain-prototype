// ===== LOG SCREEN CALENDAR =====

var logCalYear, logCalMonth;
(function () {
  var d = new Date();
  logCalYear = d.getFullYear();
  logCalMonth = d.getMonth();
})();
var logCalOpen = false;

function toggleLogCal() {
  logCalOpen = !logCalOpen;
  document.getElementById('log-cal-body').classList.toggle('open', logCalOpen);
  document.getElementById('log-cal-arrow').classList.toggle('open', logCalOpen);
  if (logCalOpen) renderLogCalendar();
}

function changeLogCalMonth(dir) {
  logCalMonth += dir;
  if (logCalMonth > 11) { logCalMonth = 0; logCalYear++; }
  if (logCalMonth < 0)  { logCalMonth = 11; logCalYear--; }
  renderLogCalendar();
}

function renderLogCalendar() {
  var now = new Date();
  var mNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  document.getElementById('log-cal-month-label').textContent = mNames[logCalMonth] + ' ' + logCalYear;

  var grid = document.getElementById('log-cal-grid');
  grid.innerHTML = '';

  ['Su','Mo','Tu','We','Th','Fr','Sa'].forEach(function (d) {
    var h = document.createElement('div');
    h.className = 'log-cal-dayname';
    h.textContent = d;
    grid.appendChild(h);
  });

  var firstDay = new Date(logCalYear, logCalMonth, 1).getDay();
  var daysInMonth = new Date(logCalYear, logCalMonth + 1, 0).getDate();

  for (var e = 0; e < firstDay; e++) {
    var em = document.createElement('div');
    em.className = 'log-cal-day empty-slot';
    grid.appendChild(em);
  }

  for (var d = 1; d <= daysInMonth; d++) {
    var cell = document.createElement('div');
    cell.className = 'log-cal-day';
    var isToday = (d === now.getDate() && logCalMonth === now.getMonth() && logCalYear === now.getFullYear());
    var data = calData[d];
    if (isToday) cell.classList.add('today');
    if (data && data.ml > 0) { cell.classList.add(data.goalMet ? 'goal-met' : 'partial'); }
    cell.textContent = d;
    (function (day, dat, isTd) {
      cell.onclick = function () {
        showLogCalDay(day, dat, isTd);
        this.parentElement.querySelectorAll('.log-cal-day').forEach(function (c) { c.classList.remove('selected'); });
        this.classList.add('selected');
      };
    })(d, data, isToday);
    grid.appendChild(cell);
  }

  document.getElementById('log-cal-detail').style.display = 'none';
}

function showLogCalDay(day, data, isToday) {
  var mNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  document.getElementById('log-cal-detail').style.display = 'block';
  document.getElementById('log-cal-det-date').textContent = mNames[logCalMonth] + ' ' + day + (isToday ? ' · Today' : '');

  if (!data || data.ml === 0) {
    document.getElementById('log-cal-det-intake').textContent = 'No data';
    document.getElementById('log-cal-det-refills').textContent = '—';
    document.getElementById('log-cal-det-pts').textContent = '—';
    document.getElementById('log-cal-det-goal').textContent = '—';
    return;
  }

  if (isToday) {
    document.getElementById('log-cal-det-intake').textContent = (intake / 1000).toFixed(1) + ' L';
    document.getElementById('log-cal-det-refills').textContent = '3 scans';
    document.getElementById('log-cal-det-pts').textContent = points + ' pts total';
    document.getElementById('log-cal-det-goal').textContent = intake >= goal ? '✅ Goal met' : '⏳ In progress';
  } else {
    document.getElementById('log-cal-det-intake').textContent = (data.ml / 1000).toFixed(1) + ' L';
    document.getElementById('log-cal-det-refills').textContent = data.refills + ' fountain scan' + (data.refills !== 1 ? 's' : '');
    document.getElementById('log-cal-det-pts').textContent = '+' + data.pts + ' pts';
    document.getElementById('log-cal-det-goal').textContent = data.goalMet ? '✅ Goal met' : '⚠️ Below goal';
  }
}
